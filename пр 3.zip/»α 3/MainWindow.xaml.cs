﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace пр_3
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public List<Employee> Employees { get; set; }
        public MainWindow()
        {
            InitializeComponent();
            Employees = new List<Employee>();
            EmployeeDataGrid.ItemsSource = Employees;
        }

        private void AddProductButton_Click(object sender, RoutedEventArgs e)
        {
            string employeeName = EmployeeNameTextBox.Text;
            string post = PostTextBox.Text;
            decimal salary;
            if (decimal.TryParse(SalaryTextBox.Text, out salary))
            {
                 
            }
            else
            {
                MessageBox.Show("Пожалуйста введите число");
            }


            
            Employees.Add(new Employee
            {
                EmployeeName = employeeName,
                Post = post,
                Salary = salary
            });
            EmployeeDataGrid.Items.Refresh();
            EmployeeNameTextBox.Clear();
            PostTextBox.Clear();
            SalaryTextBox.Clear();
        }

    }
    public class Employee
    {
        public string EmployeeName { get; set; }
        public string Post {  get; set; }
        public decimal Salary { get; set; }
    }
}